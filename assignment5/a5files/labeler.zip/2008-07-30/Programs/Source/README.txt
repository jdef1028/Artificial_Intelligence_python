For source code to all included programs, please contact HMC Sketchers
at sketchers@cs.hmc.edu.